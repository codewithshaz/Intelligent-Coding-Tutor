import streamlit as st
import json

from ai_reviewer import review_solution


def load_problems():

    with open(
        "data/problems.json",
        "r",
        encoding="utf-8"
    ) as file:

        return json.load(file)


def run():

    st.header("📝 Practice Problems")

    problems = load_problems()

    topics = sorted(
        list(
            set(
                p["topic"]
                for p in problems
            )
        )
    )

    topic = st.selectbox(
        "Select Topic",
        topics
    )

    topic_problems = [
        p
        for p in problems
        if p["topic"] == topic
    ]

    selected_problem = st.selectbox(
        "Choose Problem",
        [
            p["title"]
            for p in topic_problems
        ]
    )

    problem = next(
        p
        for p in topic_problems
        if p["title"] == selected_problem
    )

    st.subheader(problem["title"])

    st.write(problem["problem"])

    solution = st.text_area(
        "Your Solution",
        height=250
    )

    if st.button("Submit Solution"):

        if not solution.strip():

            st.warning(
                "Please enter your solution."
            )

            return

        feedback = review_solution(
            problem["problem"],
            solution
        )

        st.subheader("Feedback")

        st.write(feedback)
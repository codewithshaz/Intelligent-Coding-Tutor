import streamlit as st
from groq import Groq
from dotenv import load_dotenv
from adaptive_prompt import get_level_instruction
import os

load_dotenv()

client = Groq(
    api_key=os.getenv("GROQ_API_KEY")
)

EXPLAIN_PROMPT = """
{level_instruction}

You are an expert programming tutor.

Explain the following code line by line.

Code:
{code}

Format:

Line 1:
Explanation

Line 2:
Explanation

...

At the end provide:
- Overall purpose
- Time complexity (if applicable)
- Space complexity (if applicable)
"""

SIMPLE_PROMPT = """
You are teaching programming to a complete beginner.

Explain the following code in very simple English.

Code:
{code}

Requirements:
- Avoid technical jargon
- Use simple examples
- Explain what each line does
- Keep it easy to understand
"""


def run():

    st.header("📖 Code Explanation Engine")

    level = st.session_state.get(
        "skill_level",
        "Beginner"
    )

    st.info(f"Current Level: {level}")

    code = st.text_area(
        "Paste your code here",
        height=250,
        key="explainer_code"
    )

    col1, col2 = st.columns(2)

    with col1:
        explain_btn = st.button(
            "Explain Code",
            key="explain_btn"
        )

    with col2:
        simple_btn = st.button(
            "Simpler Explanation",
            key="simple_btn"
        )

    if explain_btn and code:

        try:

            level_instruction = get_level_instruction(level)

            prompt = EXPLAIN_PROMPT.format(
                code=code,
                level_instruction=level_instruction
            )

            response = client.chat.completions.create(
                model="llama-3.1-8b-instant",
                messages=[
                    {
                        "role": "system",
                        "content": level_instruction
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            )

            explanation = response.choices[0].message.content

            st.subheader("Explanation")
            st.write(explanation)

        except Exception as e:
            st.error(f"Error: {e}")

    if simple_btn and code:

        try:

            prompt = SIMPLE_PROMPT.format(
                code=code
            )

            response = client.chat.completions.create(
                model="llama-3.1-8b-instant",
                messages=[
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            )

            simple_explanation = response.choices[0].message.content

            st.subheader("Beginner Explanation")
            st.write(simple_explanation)

        except Exception as e:
            st.error(f"Error: {e}")
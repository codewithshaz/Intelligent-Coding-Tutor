import streamlit as st

from syntax import check_syntax
from lint import run_pyflakes
from ai_fixer import get_fix
from adaptive_prompt import get_level_instruction


def run():

    st.header("🐞 Python Error Detector & Fixer")

    level = st.session_state.get(
        "skill_level",
        "Beginner"
    )

    st.info(f"Current Level: {level}")

    code = st.text_area(
        "Paste Python Code",
        height=300,
        key="error_detector_code"
    )

    if st.button("Analyze Code", key="analyze_code_btn"):

        if not code.strip():
            st.warning("Please enter code.")
            return

        level_instruction = get_level_instruction(level)

        # ==========================
        # 1. Syntax Check
        # ==========================

        syntax_error = check_syntax(code)

        if syntax_error:

            st.error("Syntax Error Detected")
            st.code(syntax_error)

            fix = get_fix(
                code,
                f"""
{level_instruction}

Error Type: Syntax Error

{syntax_error}
"""
            )

            st.subheader("Suggested Fix")
            st.write(fix)

            return

        st.success("No Syntax Errors Found")

        # ==========================
        # 2. Lint Check
        # ==========================

        lint_errors = run_pyflakes(code)

        if lint_errors and lint_errors != "No issues found":

            st.error("Lint Issues Detected")
            st.code(lint_errors)

            fix = get_fix(
                code,
                f"""
{level_instruction}

Error Type: Lint Error

{lint_errors}
"""
            )

            st.subheader("Suggested Fix")
            st.write(fix)

            return

        st.success("No Lint Issues Found")

        # ==========================
        # 3. Runtime Check
        # ==========================

        try:

            exec(code, {})

            st.success("No Runtime Errors Found")

        except Exception as e:

            runtime_error = f"{type(e).__name__}: {e}"

            st.error("Runtime Error Detected")
            st.code(runtime_error)

            fix = get_fix(
                code,
                f"""
{level_instruction}

Error Type: Runtime Error

{runtime_error}
"""
            )

            st.subheader("Suggested Fix")
            st.write(fix)

            return

        # ==========================
        # 4. Logical Analysis
        # ==========================

        if level == "Beginner":

            logical_prompt = """
Analyze this code.

Requirements:
- Explain simply
- Mention logical mistakes
- Explain why they happen
- Show beginner-friendly fixes
- Suggest improvements
"""

        elif level == "Intermediate":

            logical_prompt = """
Analyze this code.

Requirements:
- Find logical errors
- Identify edge cases
- Suggest cleaner implementations
- Discuss complexity if relevant
"""

        else:

            logical_prompt = """
Perform an advanced code review.

Requirements:
- Detect logical flaws
- Identify algorithmic weaknesses
- Discuss complexity
- Suggest optimizations
- Mention scalability concerns
- Suggest production-grade improvements
"""

        analysis = get_fix(
            code,
            logical_prompt
        )

        st.subheader("Logical Analysis")
        st.write(analysis)
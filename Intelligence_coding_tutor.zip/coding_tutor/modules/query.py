import streamlit as st
from groq import Groq
from dotenv import load_dotenv
from adaptive_prompt import get_level_instruction
import os

load_dotenv()

client = Groq(
    api_key=os.getenv("GROQ_API_KEY")
)

def run():

    st.header("💬 Coding Chatbot")

    # Get user level
    level = st.session_state.get(
        "skill_level",
        "Beginner"
    )

    st.info(f"Current Level: {level}")

    user_question = st.text_input(
        "Ask a coding question:",
        key="chatbot_question"
    )

    if user_question:

        try:

            level_instruction = get_level_instruction(level)

            response = client.chat.completions.create(
                model="llama-3.1-8b-instant",
                messages=[
                    {
                        "role": "system",
                        "content": level_instruction
                    },
                    {
                        "role": "user",
                        "content": user_question
                    }
                ]
            )

            answer = response.choices[0].message.content

            st.subheader("AI Answer")
            st.write(answer)

        except Exception as e:
            st.error(f"Error: {e}")
import streamlit as st
from groq import Groq
from dotenv import load_dotenv
from adaptive_prompt import get_level_instruction
import os

load_dotenv()

client = Groq(
    api_key=os.getenv("GROQ_API_KEY")
)

def run():

    st.header("💻 AI Code Generator")

    level = st.session_state.get(
        "skill_level",
        "Beginner"
    )

    st.info(f"Current Level: {level}")

    language = st.selectbox(
        "Select Language",
        ["Python", "JavaScript"],
        key="generator_language"
    )

    requirement = st.text_area(
        "Describe the code you need",
        key="generator_requirement"
    )

    if st.button("Generate Code", key="generate_btn"):

        if not requirement.strip():
            st.warning("Please enter a requirement.")
            return

        # Adaptive instructions
        if level == "Beginner":

            coding_style = """
Generate beginner-friendly code.

Requirements:
- Add detailed comments
- Use descriptive variable names
- Keep logic simple
- Avoid advanced concepts
- Prioritize readability
"""

        elif level == "Intermediate":

            coding_style = """
Generate clean and structured code.

Requirements:
- Add useful comments
- Follow best practices
- Use functions when appropriate
- Balance readability and efficiency
"""

        else:

            coding_style = """
Generate production-quality code.

Requirements:
- Use best practices
- Optimize performance
- Follow clean code principles
- Use advanced techniques when appropriate
- Minimize unnecessary comments
"""

        prompt = f"""
{coding_style}

Generate only {language} code.

Requirement:
{requirement}

Rules:
- Return code only
- Do not include markdown explanations
- Do not wrap code in explanations
"""

        try:

            response = client.chat.completions.create(
                model="llama-3.1-8b-instant",
                messages=[
                    {
                        "role": "system",
                        "content": coding_style
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            )

            generated_code = response.choices[0].message.content

            generated_code = (
                generated_code
                .replace("```python", "")
                .replace("```javascript", "")
                .replace("```js", "")
                .replace("```", "")
                .strip()
            )

            st.subheader("Generated Code")

            if language == "Python":

                st.code(
                    generated_code,
                    language="python"
                )

            else:

                st.code(
                    generated_code,
                    language="javascript"
                )

            st.success(
                f"Generated for {level} level"
            )

        except Exception as e:

            st.error(f"Error: {e}")